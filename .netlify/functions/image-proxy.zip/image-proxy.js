var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/image-proxy.ts
var image_proxy_exports = {};
__export(image_proxy_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(image_proxy_exports);
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Max-Age": "86400"
      }
    };
  }
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  const params = event.queryStringParameters;
  const imageUrl = params?.url;
  if (!imageUrl) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing url parameter" }) };
  }
  let parsedUrl;
  try {
    parsedUrl = new URL(imageUrl);
    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid URL protocol" }) };
    }
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid URL" }) };
  }
  try {
    const response = await fetch(imageUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": parsedUrl.origin + "/"
      }
    });
    if (!response.ok) {
      return { statusCode: response.status, body: JSON.stringify({ error: `Upstream error: ${response.status}` }) };
    }
    const contentType = response.headers.get("content-type") || "image/png";
    const buffer = Buffer.from(await response.arrayBuffer());
    return {
      statusCode: 200,
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": "attachment",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "public, max-age=3600"
      },
      body: buffer.toString("base64"),
      isBase64Encoded: true
    };
  } catch {
    return { statusCode: 500, body: JSON.stringify({ error: "Failed to fetch image" }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
